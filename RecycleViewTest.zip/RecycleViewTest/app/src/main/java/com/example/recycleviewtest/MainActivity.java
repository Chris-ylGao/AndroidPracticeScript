package com.example.recycleviewtest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.os.Bundle;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private List<Fruit> fruitList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initFruit();
        RecyclerView recyclerView = (RecyclerView)findViewById(R.id.recycle_view);
        /**
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);

        // Set the orientation of the recycle view
        layoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
*/
        /**
         * Create a StaggeredGridLayout(column, orientation)
         */
        /**
         * Create a Grid layoutManage(context, column)
         */
        GridLayoutManager layoutManager = new GridLayoutManager(this,3 );

        recyclerView.setLayoutManager(layoutManager);
        FruitAdapter adapter = new FruitAdapter(fruitList);
        recyclerView.setAdapter(adapter);
    }

    private void initFruit(){
        for(int i = 0; i< 10 ; i++){
            Fruit apple = new Fruit(getRandomLengthNsme("Apple"), R.drawable.apple_pic);
            fruitList.add(apple);
            Fruit banana  = new Fruit(getRandomLengthNsme("banana"), R.drawable.banana_pic);
            fruitList.add(banana);
            Fruit orange  = new Fruit(getRandomLengthNsme("orange"), R.drawable.orange_pic);
            fruitList.add(orange);
        }
    }
    private String getRandomLengthNsme(String name){
        Random random = new Random();
        int length = random.nextInt(20) +1;
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i<length;i++){
            builder.append(name);
        }
        return builder.toString();
    }
}
