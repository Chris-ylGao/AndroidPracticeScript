package com.example.uiwidgettest;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText editText;
    private ImageView imageView;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = (Button) findViewById(R.id.button);
        editText = (EditText)findViewById(R.id.edit_text);
        imageView = (ImageView)findViewById(R.id.image_view);
        progressBar = (ProgressBar) findViewById(R.id.progress_bar);
        button.setOnClickListener(this);

        /**
         * override onclick
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // code to be implemented
            }
        });
         */
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button:
                //code to be implemented
                // getText() get the input from user
                String inputText = editText.getText().toString();
                Toast.makeText(MainActivity.this, inputText, Toast.LENGTH_SHORT).show();

                /**
                 * Dynamic change the image
                 * setImageResource() ---- find the drawable resource
                 */
                imageView.setImageResource(R.drawable.img_4);


                /**
                 * change the visibility of the progress bar
                 * three status of visibility: View.GONE, View.Visible, View.INVISIBLE
                 * getVisibility() --- get the visibility status
                 * setVisibility() ---- set the visibility status
                 */
                if (progressBar.getVisibility() == View.GONE) {
                    progressBar.setVisibility(View.VISIBLE);
                } else
                    progressBar.setVisibility(View.GONE);

                /**
                 * update the progress bar's progress number
                 *
                 * getProcess() ---- get the process status(number)
                 * setProcess() ---- set the process status(number)
                 */
                int progress = progressBar.getProgress();
                progress += 10;
                progressBar.setProgress(progress);


                /**
                 * create an alert dialog
                 * AlertDialog.Builder ---- create an alert dialog object;
                 * setTitle() ---- set the title;
                 * setMessage() --- set the displayed message;
                 * setCancelable() ---- set if this alter dialog can be cancelled.
                 *
                 * setPositiveButton(text, clickOnEvent) ---- set the text of positive button and override the onClick event.
                 */
                AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                dialog.setTitle("This is a Dialog");
                dialog.setMessage("Something important");
                dialog.setCancelable(false);
                dialog.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                // display the dialog
                dialog.show();


                /**
                 * NOTE: it is deprecated
                 * Create a progress dialog.
                 * ProgressDialog.Builder --- create a progress dialog object.
                 */

                ProgressDialog progressDialog = new ProgressDialog(MainActivity.this);
                progressDialog.setTitle("This is a progress dialog");
                progressDialog.setMessage("Loading...");
                // if it is false, then user cannot cancel this operation by back button.
                progressDialog.setCancelable(true);
                progressDialog.show();


                break;
            default:
        break;
    }
    }
        }

