package com.example.activitytest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class FirstActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("FirstActivity" ,this.toString());
        // setContentView() ----- load an layout
        // R.layout.first_layout  ----- the particular id of resources in R file
        setContentView(R.layout.first_layout);

        // pop out Toast message when click the button
        // findViewById ----- find the element in the layout by id
        // R.id.buttion_1 ----- the id of button defined in the layout.xml
        Button button1 = (Button) findViewById(R.id.button_1);
        // setOnClickListener() ------ register a listener for button
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Toast.makeText(context, content, time)
                // context ----- the screen to display this Toast
                // content ----- the text to be displayed
                // time ------ the time length of Toast display
                // (default: Toast.LENGTH_SHORT/ Toast.LENGTH_LONG)
               // Toast.makeText(FirstActivity.this, "You've clicked Button 1",Toast.LENGTH_SHORT).show();

                // finish current activity
                //finish();

                /**
                 * An explicit Intent can use startActivity() to jump to second activity
                 * after directly linking this activity and respond activity

                Intent explicitIntent = new Intent(FirstActivity.this, SecondActivity.class);
                startActivity(explicitIntent);
                 */

                /**
                 * An implicit Intent can filter activity by <action> and <category>

                Intent implicitIntent = new Intent("com.example.activitytest.ACTION_START");
                implicitIntent.addCategory("com.example.activitytest.MY_CATEGORY");
                startActivity(implicitIntent);
                 */

                /**
                 * An implicit intent can also access system activity.
                 * In this example, Intent.ACTION_VIEW aim to access explorer with uri "http://www.google.com"
                 * Intent.ACTION_DIAL aim to open the dial board with "tel:10086"

                Intent intent = new Intent(Intent.ACTION_DIAL);
                // setData() ---- accept an uri object
                // Uri.parse() ---- convert String to uri object.
                intent.setData(Uri.parse("tel:10086"));
                startActivity(intent);
                */

                /**
                 * Send message from first activity to second activity.

                String data = "Hello, Second Activity";
                Intent sendMessage = new Intent(FirstActivity.this, SecondActivity.class);
                // putExtra(key, value)
                sendMessage.putExtra("extra_data",data);
                startActivity(sendMessage);
                 */

                /**
                 * Start Second Activity and get the return data when second Activity finished.
                 * startActivityForResult(intent, requestCode)
                 *
                 * @see OnActivityResult()
        */
                Intent intent = new Intent(FirstActivity.this,SecondActivity.class);
                startActivityForResult(intent, 1);



                //Intent intent = new Intent(FirstActivity.this, SecondActivity.class);
               // startActivity(intent);

            }
        });

    }

    /**
     * Create a menu and display it
     * @param menu
     * @return
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // get MenuInflater().inflate(menuResource, menu) --- create menu for current activity
       getMenuInflater().inflate(R.menu.main,menu);
       //  return true ---- allow menu to display.
       return true;
    }

    /**
     * respond to the items in the menu
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.add_item:
                Toast.makeText(this, "You clicked Add", Toast.LENGTH_SHORT).show();
                break;
            case R.id.remove_item:
                Toast.makeText(this, "Y0u clicked Remove" , Toast.LENGTH_SHORT).show();
                break;
            default:
                break;
        }
        return true;
    }

    /**
     * operation of return data
     *
     * @param requestCode request code to ensure the request is sent to second activity
     * @param resultCode  result code returned by second activity(RESULT_OK or RESULT_CANCELLED)
     * @param data intent data contains returned by second activity
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        switch (requestCode){
            case 1:
                if(resultCode == RESULT_OK){
                    String returnedData = data.getStringExtra("data_return");
                    Toast.makeText(this, returnedData, Toast.LENGTH_SHORT).show();
                }
                break;
            default:
        }

    }
}
